import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="min-h-screen font-sans">
      {/* ...top sections remain unchanged... */}

      {/* Blog / Testimonials */}
      <section id="blog" className="bg-blue-50 py-12 text-center">
        <h2 className="text-3xl font-bold mb-10">Student Testimonials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
          {[
            {
              name: "Riya Shah",
              feedback: "Amazing teaching style! I built my first website at age 10.",
              photo: "https://randomuser.me/api/portraits/women/1.jpg",
              rating: 5
            },
            {
              name: "Parth Patel",
              feedback: "The internship helped me get placed in an IT company.",
              photo: "https://randomuser.me/api/portraits/men/2.jpg",
              rating: 4
            },
            {
              name: "Aanya Mehta",
              feedback: "Very supportive environment for beginners like me.",
              photo: "https://randomuser.me/api/portraits/women/3.jpg",
              rating: 5
            }
          ].map((testimonial, index) => (
            <Card key={index}>
              <CardContent className="p-6 text-left">
                <div className="flex items-center gap-4 mb-4">
                  <img
                    src={testimonial.photo}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-semibold text-blue-600">{testimonial.name}</p>
                    <p className="text-yellow-500">{"★".repeat(testimonial.rating)}</p>
                  </div>
                </div>
                <p className="italic text-gray-700">“{testimonial.feedback}”</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Blog Articles Section */}
      <section className="py-12 text-center">
        <h2 className="text-3xl font-bold mb-10">Latest Articles & Tips</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 px-4">
          {[
            {
              title: "Why Kids Should Start Coding Early",
              summary: "Discover the benefits of learning programming from a young age and how it helps cognitive growth.",
              link: "#"
            },
            {
              title: "Top 5 Programming Languages for Beginners",
              summary: "A quick guide on which languages are best for first-time coders and why.",
              link: "#"
            }
          ].map((article, index) => (
            <Card key={index}>
              <CardContent className="p-6 text-left">
                <h3 className="text-xl font-semibold mb-2">{article.title}</h3>
                <p className="text-gray-700 mb-4">{article.summary}</p>
                <a href={article.link} className="text-blue-600 hover:underline">Read More →</a>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="bg-blue-50 py-12 text-center">
        <h2 className="text-3xl font-bold mb-6">Why Choose T & A Coding Studio?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4">
          {[
            {
              title: "Experienced Mentors",
              desc: "Learn from industry professionals with years of real-world experience."
            },
            {
              title: "Hands-on Projects",
              desc: "Build real apps, games, and websites while learning by doing."
            },
            {
              title: "Career-Focused",
              desc: "Internships, job prep, and personal mentorship to guide your career."
            }
          ].map((reason, index) => (
            <Card key={index}>
              <CardContent className="p-6 text-left">
                <h3 className="text-xl font-semibold mb-2">{reason.title}</h3>
                <p className="text-gray-700">{reason.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* ...registration, contact, footer remain unchanged... */}
    </div>
  );
}
